# script for testing the fast-api deployment
import requests
import json

# The URL of your deployed API
API_URL = "https://rjuro-fastapi.hf.space"  # Replace with your actual URL
#API_URL = "http://127.0.0.1:8000"  # Replace with your actual URL

# Sample room features
sample_features = {
    "neighbourhood_cleansed": "Indre By",
    "room_type": "Entire home/apt",
    "instant_bookable": True,
    "accommodates": 10,
    "bedrooms": 5,
    "beds": 2,
    "minimum_nights_avg_ntm": 3
}

# Send POST request to the /predict endpoint
response = requests.post(f"{API_URL}/predict", json=sample_features)

# Check if the request was successful
if response.status_code == 200:
    # Parse the JSON response
    result = response.json()
    
    # Print the results
    print(f"Predicted price: {result['predicted_price']} DKK")
    print(f"Suggested price range: {result['suggested_price_range']['lower']} - {result['suggested_price_range']['upper']} DKK")
else:
    print(f"Error: {response.status_code}")
    print(response.text)